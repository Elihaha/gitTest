create procedure update_sku(IN goods_SkuNo varchar(50), IN sku_stock int)
  BEGIN
	--  以銷售額
  DECLARE count int  default 0;
	--   當前銷售額
  DECLARE currentCount int  default 0;
	--   當前 剩餘庫存
  DECLARE currentStock int  default 0;
	select   soldout_count , stock into currentCount, currentStock  from  goods_sku where sku_no = goods_SkuNo;
 
  set  count = currentCount + currentStock -`sku_stock`;
	
 	update  goods_sku  set  soldout_count = count
-- 	, stock =`sku_stock` 
	where sku_no = goods_SkuNo;
	
  --  select soldout_count into  sku_stock  from goods_sku where sku_no = goods_SkuNo;
	 
END;

