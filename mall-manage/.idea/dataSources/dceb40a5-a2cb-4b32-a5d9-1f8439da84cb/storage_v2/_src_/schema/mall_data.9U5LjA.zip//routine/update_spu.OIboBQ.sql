create procedure update_spu(IN goods_SpuNo varchar(50), IN spu_stock int)
  BEGIN
	--  以銷售額
  DECLARE count int  default 0;
	--   當前銷售額
  DECLARE currentCount int  default 0;
	--   當前 剩餘庫存
  DECLARE currentStock int  default 0;
	select   soldout_count ,  total_stock into  currentCount,currentStock from  goods_spu where spu_no = goods_SpuNo;
 
  set  count = currentCount + currentStock -`spu_stock`;
	
	update  goods_spu  set  soldout_count = count
-- 	, total_stock =`spu_stock` 
where spu_no = goods_SpuNo;
	
  --   select soldout_count into  count  from goods_spu where spu_no = goods_SpuNo;
	 
END;

